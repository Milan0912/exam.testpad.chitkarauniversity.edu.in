import { useState } from 'react'
import './App.css'
import axios from 'axios'

function App() {
  const [pdata, setdata] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  function butt() {
    axios.get('https://fakestoreapi.com/products')
      .then((res) => {
        console.log(res.data);
        setdata(res.data); // Fix here
      });
  }

  function handleChange(event) {
    const productId = event.target.value;
    const product = pdata.find(p => p.id === Number(productId));
    setSelectedProduct(product);
  }

  return (
    <>
      <button onClick={butt}>click</button>
      {pdata.length > 0 && (
        <select onChange={handleChange}>
          <option value="">Select a product</option>
          {pdata.map((product) => (
            <option key={product.id} value={product.id}>
              {product.title}
            </option>
          ))}
        </select>
      )}
      {selectedProduct && <Card product={selectedProduct} />}
    </>
  );
}

function Card({ product }) {
  return (
    <div>
      <img src={product.image} alt={product.title} />
      <h3>{product.title}</h3>
      <p>{product.description}</p>
    </div>
  );
}

export default App;
